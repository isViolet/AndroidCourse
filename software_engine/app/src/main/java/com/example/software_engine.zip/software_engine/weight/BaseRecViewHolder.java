package com.example.software_engine.weight;

import android.view.View;

import androidx.recyclerview.widget.RecyclerView;

public class BaseRecViewHolder extends RecyclerView.ViewHolder {
    public BaseRecViewHolder(View itemView) {

        super(itemView);
    }
}
