package com.example.software_engine.config;

public class Config {
    public static final String URL_KEY = "http://www.tuling123.com/openapi/api";
    public static final String APP_KEY = "065b58cbef7e4634be760182a37d419e";//此处是你申请的Apikey
}
